package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;


@Repository
public class LeaveDao {
	
	@Autowired
	JdbcTemplate jdbc;
	
	public List<LeaveHistory> serachbyempid(int id){
		String cmd = "select * from leave_history where emp_id=?";
		List<LeaveHistory> LeaveList=jdbc.query(cmd,new Object[] {id}, new RowMapper<LeaveHistory>() {

			public LeaveHistory mapRow(ResultSet rs, int arg1) throws SQLException {
			    LeaveHistory lh=new LeaveHistory();
			    lh.setLeave_id(rs.getInt("LEAVE_ID"));
			    lh.setLeave_no_of_days(rs.getInt("LEAVE_NO_OF_DAYS"));
			    lh.setLeave_mngr_comments(rs.getString("LEAVE_MNGR_COMMENTS"));
			    lh.setEmpid(rs.getInt("EMP_ID"));
			    lh.setLeave_start_date(rs.getDate("LEAVE_START_DATE"));
			    lh.setLeave_end_date(rs.getDate("LEAVE_END_DATE"));
			    lh.setLeave_type(rs.getString("LEAVE_TYPE"));
			    lh.setLeave_status(rs.getString("LEAVE_STATUS"));
			    lh.setLeave_reason(rs.getString("LEAVE_REASON"));
			    
			    return lh;
				
			}


			
		});
		return LeaveList;
	}
  
	
	public List<LeaveHistory> serachpendingleavesofemp(int id){
		String cmd = "select * from leave_history where emp_id=? and LEAVE_STATUS=?";
		List<LeaveHistory> LeaveList=jdbc.query(cmd,new Object[] {id,"PENDING"}, new RowMapper<LeaveHistory>() {

			public LeaveHistory mapRow(ResultSet rs, int arg1) throws SQLException {
			    LeaveHistory lh=new LeaveHistory();
			    lh.setLeave_id(rs.getInt("LEAVE_ID"));
			    lh.setLeave_no_of_days(rs.getInt("LEAVE_NO_OF_DAYS"));
			    lh.setLeave_mngr_comments(rs.getString("LEAVE_MNGR_COMMENTS"));
			    lh.setEmpid(rs.getInt("EMP_ID"));
			    lh.setLeave_start_date(rs.getDate("LEAVE_START_DATE"));
			    lh.setLeave_end_date(rs.getDate("LEAVE_END_DATE"));
			    lh.setLeave_type(rs.getString("LEAVE_TYPE"));
			    lh.setLeave_status(rs.getString("LEAVE_STATUS"));
			    lh.setLeave_reason(rs.getString("LEAVE_REASON"));
			    
			    return lh;
				
			}


			
		});
		return LeaveList;
	}
	
	public void updateLeaveStatus(int levid, String  mgr_comments,String status) {
		String cmd = "Update leave_history set LEAVE_MNGR_COMMENTS=?,LEAVE_STATUS=?  WHERE LEAVE_ID=?";
		jdbc.update(cmd, new Object[] {mgr_comments,status,levid});
	}
 
}
