package com.example.demo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class LeaveService {
	
	@Autowired
	LeaveRepository repo;
	
	@Autowired
	LeaveDao dao;
	
	@Autowired
	EmployeeDao edao;
	
	@Autowired
	EmployeeService serv;
	
	public LeaveHistory serachleave(int id) {
		return repo.findById(id).get();
	}
	
	public List<LeaveHistory> serahbyempid(int id){
		return dao.serachbyempid(id);
	}
	
	public List<LeaveHistory> getpendingleaves(int id){
		return dao.serachpendingleavesofemp(id);
	}
	
	public String applyleave(LeaveHistory ls) {
		long ms = ls.getLeave_end_date().getTime() - ls.getLeave_start_date().getTime();
	    long m = ms / (1000 * 24 * 60 * 60);
	    int days = (int) m;
	    days = days + 1;
	    if(days <= 0) {
	    	return "Leave end date cannot be less than Leave start date"; 
	    }
	    ls.setLeave_no_of_days(days);
		int no_days=edao.getleavebalnce(ls.getEmpid());
		if(ls.getLeave_no_of_days() > no_days) {
			return "Insuffient Leave Balance";
		}
		ls.setLeave_status("PENDING");
		repo.save(ls);
		edao.updateEmpLeaveBal(ls.getEmpid(), ls.getLeave_no_of_days());
		return "Leave Applied Successfully";
	}
	
	public String approve_or_deny(int levid,int mgrid,String mgrcomments,String status) {
		LeaveHistory ls=repo.findById(levid).get();
		Employee emp=serv.serachEmp(ls.getEmpid());
		if(emp.getEmp_manager_id() != mgrid) {
			return "UnAuthourized Manager";
		}
		if(status.toLowerCase().equals("yes")) {
			dao.updateLeaveStatus(ls.getLeave_id(), mgrcomments, "APPROVED");
			return "Leave Approved by Managar";
		}
		else {
			dao.updateLeaveStatus(ls.getLeave_id(), mgrcomments, "DENIED");
			edao.updateLeavebal_afterdeny(ls.getEmpid(), ls.getLeave_no_of_days());
			return "Leave DENIED by Managar";
		}
	}

}
