package com.example.demo;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee {
  
	@Id
	private int emp_id;
	private String emp_name;
	private String emp_mail;
	private Date emp_dt_join;
	private String emp_dept;
	private int emp_manager_id;
	private int emp_avail_leave_bal;
	public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public String getEmp_mail() {
		return emp_mail;
	}
	public void setEmp_mail(String emp_mail) {
		this.emp_mail = emp_mail;
	}
	public Date getEmp_dt_join() {
		return emp_dt_join;
	}
	public void setEmp_dt_join(Date emp_dt_join) {
		this.emp_dt_join = emp_dt_join;
	}
	public String getEmp_dept() {
		return emp_dept;
	}
	public void setEmp_dept(String emp_dept) {
		this.emp_dept = emp_dept;
	}
	public int getEmp_manager_id() {
		return emp_manager_id;
	}
	public void setEmp_manager_id(int emp_manager_id) {
		this.emp_manager_id = emp_manager_id;
	}
	public int getEmp_avail_leave_bal() {
		return emp_avail_leave_bal;
	}
	public void setEmp_avail_leave_bal(int emp_avail_leave_bal) {
		this.emp_avail_leave_bal = emp_avail_leave_bal;
	}
	
	
	
	
	
	
	
}
