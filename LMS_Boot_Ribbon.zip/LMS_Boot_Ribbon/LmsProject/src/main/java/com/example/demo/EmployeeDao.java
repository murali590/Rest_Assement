package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDao {
    
	@Autowired
	JdbcTemplate jdbc;
	
	public void updateEmpLeaveBal(int empid, int no_days) {
		String cmd = "Update employee set EMP_AVAIL_LEAVE_BAL=EMP_AVAIL_LEAVE_BAL-?  WHERE EMP_ID=?";
		jdbc.update(cmd, new Object[] {no_days,empid});
	}
	
	public void updateLeavebal_afterdeny(int empid, int no_days) {
		String cmd = "Update employee set EMP_AVAIL_LEAVE_BAL=EMP_AVAIL_LEAVE_BAL+?  WHERE EMP_ID=?";
		jdbc.update(cmd, new Object[] {no_days,empid});
	}
	
	
	public int getleavebalnce(int empid) {
		String cmd = "select * from employee where Emp_ID=?";
		List<Employee> empList=jdbc.query(cmd,new Object[] {empid}, new RowMapper<Employee>() {

			public Employee mapRow(ResultSet rs, int arg1) throws SQLException {
				Employee emp=new Employee();
				emp.setEmp_avail_leave_bal(rs.getInt("EMP_AVAIL_LEAVE_BAL"));
				return emp;
			}


			
		});
		return empList.get(0).getEmp_avail_leave_bal();
	}
}
