package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LeaveController {
	
	@Autowired
	LeaveService service;
	
	@GetMapping("/getleave/{id}")
	public LeaveHistory getLeave(@PathVariable int id) {
		return service.serachleave(id);
	}
	
	@GetMapping("/getleavebyemp/{id}")
	public List<LeaveHistory> getleaveinfobyempid(@PathVariable int id){
		return service.serahbyempid(id);
	}
	
	@GetMapping("/showpendingleaves/{id}")
	public List<LeaveHistory> showpendingleaves(@PathVariable int id){
		return service.getpendingleaves(id);
	}
	
	@PostMapping("/applyLeave")
	public String add(@RequestBody LeaveHistory ls) {
//		System.out.println(ls);
//		return "ok";
		return service.applyleave(ls);
	}
	
	@PostMapping("/approveordeny/{levid}/{mgrid}/{mgrcomments}/{status}")
    public String approveordeny(@PathVariable int levid,@PathVariable int mgrid,@PathVariable String mgrcomments,@PathVariable String status) {
		System.out.println(levid);
		System.out.println(mgrid);
		System.out.println(mgrcomments);
		System.out.println(status);
		return service.approve_or_deny(levid, mgrid, mgrcomments, status);
	}
}
