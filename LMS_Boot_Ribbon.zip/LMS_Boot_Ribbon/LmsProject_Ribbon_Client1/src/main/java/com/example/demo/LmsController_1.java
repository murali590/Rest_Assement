package com.example.demo;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@RestController
public class LmsController_1 {

	

	@Autowired
	private LoadBalancerClient lba;

	@GetMapping(value= "/serachemp/{id}")
	public Object getGreetings(@PathVariable String id) throws RestClientException, IOException {
		ServiceInstance servInstance= lba.choose("LmsProject-Client");
		System.out.println("HI " +servInstance.getUri());

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/showallemps/"+id;

		RestTemplate restTemplate= new RestTemplate();
		ResponseEntity<Object> response= null;
		
	//	ResponseEntity<Object[]> res=null;
		try{
		//	res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object[].class);
			response= restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), Object.class);
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
		System.out.println("Output= " + response.getBody());
		return response.getBody();
	}
	
	@GetMapping(value= "/showemps")
	public Object[] getemps() throws RestClientException, IOException {
		ServiceInstance servInstance= lba.choose("LmsProject-Client");
		System.out.println("HI " +servInstance.getUri());

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/showallemps";

		RestTemplate restTemplate= new RestTemplate();
		ResponseEntity<Object[]> response= null;
		
	//	ResponseEntity<Object[]> res=null;
		try{
		//	res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object[].class);
			response= restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), Object[].class);
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
		System.out.println("Output= " + response.getBody());
		return response.getBody();
	}
	
	@GetMapping(value= "/serachLeave/{id}")
	public Object getLeave(@PathVariable String id) throws RestClientException, IOException {
		ServiceInstance servInstance= lba.choose("LmsProject-Client");
		System.out.println("HI " +servInstance.getUri());

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/getleave/"+id;

		RestTemplate restTemplate= new RestTemplate();
		ResponseEntity<Object> response= null;
		
	//	ResponseEntity<Object[]> res=null;
		try{
		//	res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object[].class);
			response= restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), Object.class);
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
		System.out.println("Output= " + response.getBody());
		return response.getBody();
	}
	
	@GetMapping(value= "/showLeavebyemp/{id}")
	public Object[] showleavebyemp(@PathVariable int id) throws RestClientException, IOException {
		ServiceInstance servInstance= lba.choose("LmsProject-Client");
		System.out.println("HI " +servInstance.getUri());

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/getleavebyemp/"+id;

		RestTemplate restTemplate= new RestTemplate();
		ResponseEntity<Object[]> response= null;
		
	//	ResponseEntity<Object[]> res=null;
		try{
		//	res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object[].class);
			response= restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), Object[].class);
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
		System.out.println("Output= " + response.getBody());
		return response.getBody();
	}
	
	@GetMapping(value= "/showpendingleaves/{id}")
	public Object[] showpending(@PathVariable int id) throws RestClientException, IOException {
		ServiceInstance servInstance= lba.choose("LmsProject-Client");
		System.out.println("HI " +servInstance.getUri());

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/showpendingleaves/"+id;

		RestTemplate restTemplate= new RestTemplate();
		ResponseEntity<Object[]> response= null;
		
	//	ResponseEntity<Object[]> res=null;
		try{
		//	res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object[].class);
			response= restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), Object[].class);
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
		System.out.println("Output= " + response.getBody());
		return response.getBody();
	}
	
	@PostMapping("/Applyleave")
	public String ApplyLeave(@RequestBody LeaveHistory ls) {
		ServiceInstance servInstance= lba.choose("LmsProject-Client");
		System.out.println("HI " +servInstance.getUri());

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/applyLeave";

		RestTemplate restTemplate= new RestTemplate();
		ResponseEntity<String> response= null;
		
	//	ResponseEntity<Object[]> res=null;
		try{
		//	res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object[].class);
			response= restTemplate.postForEntity( baseUrl, ls, String.class );
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
		System.out.println("Output= " + response.getBody());
		return response.getBody();
	}
	
	@PostMapping("/approveordeny/{levid}/{mgrid}/{mgrcomments}/{status}")
    public String approveordeny(@PathVariable int levid,@PathVariable int mgrid,@PathVariable String mgrcomments,@PathVariable String status) {
		
		ServiceInstance servInstance= lba.choose("LmsProject-Client");
		System.out.println("HI " +servInstance.getUri());

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/approveordeny/"+levid+"/"+mgrid+"/"+mgrcomments+"/"+status;

		RestTemplate restTemplate= new RestTemplate();
		ResponseEntity<String> response= null;
		
	//	ResponseEntity<Object[]> res=null;
		try{
		//	res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object[].class);
			response= restTemplate.postForEntity( baseUrl, null , String.class );
			
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
		System.out.println("Output= " + response.getBody());
		return response.getBody();
	}
	

	private static HttpEntity<?> getHeaders() throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}
}
