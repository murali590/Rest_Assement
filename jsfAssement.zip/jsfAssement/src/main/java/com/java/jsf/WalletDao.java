package com.java.jsf;

import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

@ManagedBean(name="walletdao")
public class WalletDao {
	
	static Session sess;
	Query q;
	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
	
	static {
		sess=new SessionMenu().getSession();
	}
	
	public List<Wallet> getallwallets(){
		q=sess.createQuery("from Wallet");
		List<Wallet> list=q.list();
		return list;
	}
	
	public String saveWallet(Wallet wall) {
		Transaction t=sess.beginTransaction();
		sess.save(wall);
		t.commit();
		sess.clear();
	    return "ShowWallets.xhtml?faces-redirect=true";
	}
	
	public String edit(Wallet wall) {
		sessionMap.put("editwallet", wall);
		return "Walletedit.xhtml?faces-redirect=true";
	}
	
	public String deletewallet(Wallet wall ) {
		Transaction t=sess.beginTransaction();
		sess.delete(wall);
		t.commit();
		return "ShowWallets.xhtml?faces-redirect=true";
	}
	
//	public static void main(String[] args) {
//		System.out.println(new WalletDao().getallwallets());
//	}

}
