package com.java.jsf;

import javax.faces.bean.ManagedBean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@ManagedBean
@Entity
@Table(name="Menu")
public class Menu {
	
	@Id
	@Column(name="MENU_ID")
	private int menu_id;
	
	@Column(name="MENU_ITEM")
	private String menu_item;
	
	@Column(name="MENU_PRICE")
	private int menu_price;
	
	@Column(name="MENU_CALORIES")
	private double menu_calroies;
	
	@Column(name="MENU_TYPE")
	private String menu_type;
	
	@Column(name="MENU_STATUS")
	private String menu_status;
	
	@Column(name="MENU_RATING")
	private String menu_rating;

	public int getMenu_id() {
		return menu_id;
	}

	public void setMenu_id(int menu_id) {
		this.menu_id = menu_id;
	}

	public String getMenu_item() {
		return menu_item;
	}

	public void setMenu_item(String menu_item) {
		this.menu_item = menu_item;
	}

	public int getMenu_price() {
		return menu_price;
	}

	public void setMenu_price(int menu_price) {
		this.menu_price = menu_price;
	}

	public double getMenu_calroies() {
		return menu_calroies;
	}

	public void setMenu_calroies(double menu_calroies) {
		this.menu_calroies = menu_calroies;
	}

	public String getMenu_type() {
		return menu_type;
	}

	public void setMenu_type(String menu_type) {
		this.menu_type = menu_type;
	}

	public String getMenu_status() {
		return menu_status;
	}

	public void setMenu_status(String menu_status) {
		this.menu_status = menu_status;
	}

	public String getMenu_rating() {
		return menu_rating;
	}

	public void setMenu_rating(String menu_rating) {
		this.menu_rating = menu_rating;
	}

	@Override
	public String toString() {
		return "Meanu [menu_id=" + menu_id + ", menu_item=" + menu_item + ", menu_price=" + menu_price
				+ ", menu_calroies=" + menu_calroies + ", menu_type=" + menu_type + ", menu_status=" + menu_status
				+ ", menu_rating=" + menu_rating + "]";
	}

	public Menu() {
	
		// TODO Auto-generated constructor stub
	}

	
	
}
