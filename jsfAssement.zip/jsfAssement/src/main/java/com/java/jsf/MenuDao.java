package com.java.jsf;

import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;




@ManagedBean(name="menudao")
public class MenuDao {
	
	static Session sess;
	Query q;
	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
	
	static {
		sess=new SessionMenu().getSession();
	}
	
	public List<Menu> getallmenu(){
		q=sess.createQuery("from Menu");
		List<Menu> list=q.list();
		return list;
	}
	
	public String SaveItem(Menu menu) {
		Transaction t=sess.beginTransaction();
		sess.save(menu);
		t.commit();
		sess.clear();
		return "MenuShow.xhtml?faces-redirect=true";
	}
	
	public String edit(Menu menu) {
		 	sessionMap.put("editMenu", menu);
			return "Menuedit.xhtml?faces-redirect=true";
		}
	
	
	
	public String Delteitem(Menu menu) {
		Transaction t=sess.beginTransaction();
		sess.delete(menu);
		t.commit();
		return "MenuShow.xhtml?faces-redirect=true";
	}

	
//	public static void main(String[] args) {
//		System.out.println(new MenuDao().getallmenu());
//	}
}
