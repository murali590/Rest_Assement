package com.java.jsf;

import javax.faces.bean.ManagedBean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@ManagedBean
@Entity
@Table(name="WALLET")
public class Wallet {
	
	@Id
	@Column(name="Wal_Id")
	private int wall_id;
	
	@Column(name="Cus_Id")
	private int cust_id;
	
	@Column(name="Wal_Amount")
	private double wal_amount;
	
	@Column(name="Wal_Source")
	private String wal_source;

	public int getWall_id() {
		return wall_id;
	}

	public void setWall_id(int wall_id) {
		this.wall_id = wall_id;
	}

	public int getCust_id() {
		return cust_id;
	}

	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}

	public double getWal_amount() {
		return wal_amount;
	}

	public void setWal_amount(double wal_amount) {
		this.wal_amount = wal_amount;
	}

	public String getWal_source() {
		return wal_source;
	}

	public void setWal_source(String wal_source) {
		this.wal_source = wal_source;
	}

	@Override
	public String toString() {
		return "Wallet [wall_id=" + wall_id + ", cust_id=" + cust_id + ", wal_amount=" + wal_amount + ", wal_source="
				+ wal_source + "]";
	}
	
	

}
