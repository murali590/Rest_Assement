package com.java.college;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class CollegeDao {
	
	SessionFactory sf = new AnnotationConfiguration().configure().buildSessionFactory();
	Session s = sf.openSession();
	Query q;
	
	public String AddSubject(Subjects sub) {
		Transaction t=s.beginTransaction();
		s.save(sub);
		t.commit();
		return "Subject Added to database";
	}
	
	public List<String> getallinstructors(){
		q=s.createQuery("select distinct(instructor) from Subjects");
		List<String> list=q.list();
		
		return list;
	}
	
	
	public String generateCourseId() {
		q=s.createQuery("select max(cou.courseNo) from CourseList cou");
		List<String> courseids=q.list();
		String newcourseid=null;
		
		if(courseids.get(0) == null) {
			return "C001";
		}
		int courseno=  Integer.parseInt(courseids.get(0).substring(1));
		++courseno;
		
		
		if(courseno >= 0 && courseno < 10) {
			newcourseid="C00"+courseno;
		}else if(courseno >= 10 && courseno <100) {
			newcourseid="C0"+courseno;
		}else {
			newcourseid="C"+courseno;
		}
   	
		return newcourseid;
	}
	
	public String genrateFeedbackId() {
		
		q=s.createQuery("select max(fb.fid) from FeedBack fb");
		List<String> feedbackids=q.list();
		String newfeedbackid=null;
		
		if(feedbackids.get(0) == null) {
			return "F001";
		}
		int feedbackno=  Integer.parseInt(feedbackids.get(0).substring(1));
		++feedbackno;
		
		
		if(feedbackno >= 0 && feedbackno < 10) {
			newfeedbackid="F00"+feedbackno;
		}else if(feedbackno >= 10 && feedbackno <100) {
			newfeedbackid="F0"+feedbackno;
		}else {
			newfeedbackid="F"+feedbackno;
		}
   	
		return newfeedbackid;
		
	}
	
	public String AddCourse(CourseList cou) {
		cou.setCourseNo(generateCourseId());
		Transaction t = s.beginTransaction();
 		s.save(cou);
 		t.commit();	
 		return "Course Added to Database";
	}
	
	public List<String> getsubjects(String instruct){
		q=s.createQuery("from Subjects where instructor ='"+instruct+"'");
		List<Subjects> sublist=q.list();
		List<String> subs=new ArrayList<String>();
		
		for (Subjects sb : sublist) {
			subs.add(sb.getSubject());
		}
		
		return subs;
	}
	
	public String addFeedback(FeedBack fb) {
		fb.setFid(genrateFeedbackId());
		Transaction t=s.beginTransaction();
		s.save(fb);
		t.commit();
		return "Your FeedBack is Recorded";
	}
	
	public static void main(String[] args) {
	   List<String> ins=new CollegeDao().getallinstructors();
	   for (String string : ins) {
		System.out.println(string);
	  }
	}
}
