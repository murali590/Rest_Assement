package com.java.college;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Feedback")
public class FeedBack {
	
	
	@Id
	@Column(name="FID")
	private String fid;
	
	@Column(name="StudentName")
	private String studentname;
	
	@Column(name=" instructor")
	private String instructor;
	
	@Column(name="subject")
	private String subject;
	
	@Column(name="")
	private String fbvalue;
	
	@Column(name="FbValue")
	public String getFid() {
		return fid;
	}
	public void setFid(String fid) {
		this.fid = fid;
	}
	public String getStudentname() {
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public String getInstructor() {
		return instructor;
	}
	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getFbvalue() {
		return fbvalue;
	}
	public void setFbvalue(String fbvalue) {
		this.fbvalue = fbvalue;
	}
	public FeedBack() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "FeedBack [fid=" + fid + ", studentname=" + studentname + ", instructor=" + instructor + ", subject="
				+ subject + ", fbvalue=" + fbvalue + "]";
	}
	
	

}
